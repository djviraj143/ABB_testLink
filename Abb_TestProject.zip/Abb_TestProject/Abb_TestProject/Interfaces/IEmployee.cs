﻿using Abb_TestProject.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Abb_TestProject.Interfaces
{
    public interface IEmployee
    {
        Task<ActionResult<IEnumerable<Employees>>> GetAllEmployees();

        Task<ActionResult<Employees>> GetEmployeeById(int id);

        Task<ActionResult<Employees>> SaveEmployee(Employees employees);

        Task<string> UpdateEmployee(int id, Employees employee);

        Task<ActionResult<Employees>> DeleteEmployee(int id);
    }
}
