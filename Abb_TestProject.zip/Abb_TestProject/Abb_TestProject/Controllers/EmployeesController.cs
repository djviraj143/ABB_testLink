﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Abb_TestProject.Models;
using Microsoft.AspNetCore.Authorization;
using Abb_TestProject.Interfaces;
using System.Data;

namespace Abb_TestProject.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly ABB_TestContext _context;

        private readonly IEmployee _employeeService;

        public EmployeesController(ABB_TestContext context, IEmployee employeeService)
        {
            _employeeService = employeeService;
            _context = context;
        }

        // GET: api/Employees
        [AllowAnonymous]
        [HttpGet]
        public ActionResult<IEnumerable<Employees>> GetEmployees()
        {
            var data = _employeeService.GetAllEmployees();

            return data.Result;
        }

        // GET: api/Employees/5
        [AllowAnonymous]
        [Produces("application/json")]
        [HttpGet("{id}")]
        public ActionResult<Employees> GetEmployees(int id)
        {
            var employees = _employeeService.GetEmployeeById(id);

            if (employees == null)
            {
                return NotFound();
            }

            return employees.Result;
        }

        // PUT: api/Employees/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult PutEmployees(int id, Employees employees)
        {
            if (id != employees.Id)
            {
                return BadRequest();
            }

            var empData = _employeeService.UpdateEmployee(id, employees);

            return Ok(empData.Result);

        }

        // POST: api/Employees
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public ActionResult<Employees> PostEmployees(Employees employees)
        {

            var data = _employeeService.SaveEmployee(employees);

            return CreatedAtAction("GetEmployees", new { id = employees.Id }, data.Result.Value);
        }

        // DELETE: api/Employees/5
        [HttpDelete("{id}")]
        public ActionResult<Employees> DeleteEmployees(int id)
        {
            var employees = _context.Employees.Find(id);
            if (employees == null)
            {
                return NotFound();
            }
            var data = _employeeService.DeleteEmployee(id);

            return data.Result;
        }
    }
}
