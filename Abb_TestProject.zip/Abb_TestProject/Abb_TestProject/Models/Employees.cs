﻿using System;
using System.Collections.Generic;

namespace Abb_TestProject.Models
{
    public partial class Employees
    {
        public int Id { get; set; }
        public string EmpName { get; set; }
        public string EmailId { get; set; }
        public string Mobile { get; set; }
        public string Designation { get; set; }
        public DateTime? JoiningDate { get; set; }
        public decimal? Salary { get; set; }
        public string EmpAddress { get; set; }
        public string City { get; set; }
    }
}


// table query for you reference:-

//CREATE TABLE Employees
//(id INT NOT NULL IDENTITY(1,1),
//  emp_name VARCHAR(50),
//  emailId VARCHAR(50) NOT NULL,
//  mobile VARCHAR(15),
//  designation VARCHAR(50) NULL,
//  joiningDate DATETIME NULL,
//  salary MONEY,
//  emp_address VARCHAR(250),
//  city VARCHAR(50),
//  CONSTRAINT[PK_Employee] PRIMARY KEY CLUSTERED(id)
//);