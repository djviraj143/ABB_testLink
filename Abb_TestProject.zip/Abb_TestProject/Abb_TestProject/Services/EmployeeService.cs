﻿using Abb_TestProject.Interfaces;
using Abb_TestProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace Abb_TestProject.Services
{
    public class EmployeeService : IEmployee
    {
        private readonly ABB_TestContext _context;

        public EmployeeService(ABB_TestContext context)
        {
            _context = context;
        }

        public async Task<ActionResult<IEnumerable<Employees>>> GetAllEmployees()
        {
            return await _context.Employees.ToListAsync();
        }

        public async Task<ActionResult<Employees>> GetEmployeeById(int id)
        {
            var employees = await _context.Employees.FindAsync(id);

            return employees;
        }

        public async Task<ActionResult<Employees>> SaveEmployee(Employees employees)
        {
            _context.Employees.Add(employees);
            await _context.SaveChangesAsync();

            return employees;
        }

        public async Task<string> UpdateEmployee(int id, Employees employee)
        {
            _context.Entry(employee).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();

                return "Employee details successfully updated with id:- " + employee.Id;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeesExists(id))
                {
                    return "No Employee found with the id:- " + employee.Id;
                }
                else
                {
                    throw;
                }
            }            
        }

        public async Task<ActionResult<Employees>> DeleteEmployee(int id)
        {
            var employees = await _context.Employees.FindAsync(id);
            if (employees != null)
            {
                _context.Employees.Remove(employees);
                await _context.SaveChangesAsync();
            }

            return employees;
        }

        private bool EmployeesExists(int id)
        {
            return _context.Employees.Any(e => e.Id == id);
        }
    }
}
